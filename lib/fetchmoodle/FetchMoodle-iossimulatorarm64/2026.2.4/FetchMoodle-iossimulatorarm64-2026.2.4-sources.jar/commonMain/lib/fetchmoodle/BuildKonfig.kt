package lib.fetchmoodle

import kotlin.String

internal object BuildKonfig {
  public val MOODLE_TEST_URL: String = "https://moodle.hainan-biuh.edu.cn"

  public val MOODLE_TEST_USERNAME: String = "chen.junhao.25"

  public val MOODLE_TEST_PASSWORD: String = "w09t3t0r1sTezC@md"
}
